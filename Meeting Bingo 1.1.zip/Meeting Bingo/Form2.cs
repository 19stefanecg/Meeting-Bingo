﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Meeting_Bingo
{
    public partial class uwuForm : Form
    {
        public uwuForm()
        {
            InitializeComponent();
        }

        private void uwuButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
