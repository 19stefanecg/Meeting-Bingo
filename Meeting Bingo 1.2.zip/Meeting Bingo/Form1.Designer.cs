﻿
namespace Meeting_Bingo
{
    partial class startupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(startupForm));
            this.button1 = new System.Windows.Forms.Button();
            this.bingoButton1 = new System.Windows.Forms.Button();
            this.bingoButton5 = new System.Windows.Forms.Button();
            this.bingoButton2 = new System.Windows.Forms.Button();
            this.bingoButton4 = new System.Windows.Forms.Button();
            this.bingoButton3 = new System.Windows.Forms.Button();
            this.bingoButton8 = new System.Windows.Forms.Button();
            this.bingoButton9 = new System.Windows.Forms.Button();
            this.bingoButton7 = new System.Windows.Forms.Button();
            this.bingoButton10 = new System.Windows.Forms.Button();
            this.bingoButton6 = new System.Windows.Forms.Button();
            this.bingoButtonFree = new System.Windows.Forms.Button();
            this.bingoButton14 = new System.Windows.Forms.Button();
            this.bingoButton12 = new System.Windows.Forms.Button();
            this.bingoButton15 = new System.Windows.Forms.Button();
            this.bingoButton11 = new System.Windows.Forms.Button();
            this.bingoButton18 = new System.Windows.Forms.Button();
            this.bingoButton19 = new System.Windows.Forms.Button();
            this.bingoButton17 = new System.Windows.Forms.Button();
            this.bingoButton20 = new System.Windows.Forms.Button();
            this.bingoButton16 = new System.Windows.Forms.Button();
            this.bingoButton23 = new System.Windows.Forms.Button();
            this.bingoButton24 = new System.Windows.Forms.Button();
            this.bingoButton22 = new System.Windows.Forms.Button();
            this.bingoButton25 = new System.Windows.Forms.Button();
            this.bingoButton21 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.shuffleButton = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.bingoWinBox = new System.Windows.Forms.TextBox();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(0, 0);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // bingoButton1
            // 
            this.bingoButton1.Location = new System.Drawing.Point(16, 105);
            this.bingoButton1.Name = "bingoButton1";
            this.bingoButton1.Size = new System.Drawing.Size(80, 80);
            this.bingoButton1.TabIndex = 1;
            this.bingoButton1.TabStop = false;
            this.bingoButton1.Text = "1";
            this.bingoButton1.UseVisualStyleBackColor = true;
            this.bingoButton1.Click += new System.EventHandler(this.bingoButton1_Click);
            // 
            // bingoButton5
            // 
            this.bingoButton5.Location = new System.Drawing.Point(396, 105);
            this.bingoButton5.Name = "bingoButton5";
            this.bingoButton5.Size = new System.Drawing.Size(80, 80);
            this.bingoButton5.TabIndex = 2;
            this.bingoButton5.TabStop = false;
            this.bingoButton5.Text = "5";
            this.bingoButton5.UseVisualStyleBackColor = true;
            this.bingoButton5.Click += new System.EventHandler(this.bingoButton5_Click);
            // 
            // bingoButton2
            // 
            this.bingoButton2.Location = new System.Drawing.Point(111, 105);
            this.bingoButton2.Name = "bingoButton2";
            this.bingoButton2.Size = new System.Drawing.Size(80, 80);
            this.bingoButton2.TabIndex = 3;
            this.bingoButton2.TabStop = false;
            this.bingoButton2.Text = "2";
            this.bingoButton2.UseVisualStyleBackColor = true;
            this.bingoButton2.Click += new System.EventHandler(this.bingoButton2_Click);
            // 
            // bingoButton4
            // 
            this.bingoButton4.Location = new System.Drawing.Point(301, 105);
            this.bingoButton4.Name = "bingoButton4";
            this.bingoButton4.Size = new System.Drawing.Size(80, 80);
            this.bingoButton4.TabIndex = 4;
            this.bingoButton4.TabStop = false;
            this.bingoButton4.Text = "4";
            this.bingoButton4.UseVisualStyleBackColor = true;
            this.bingoButton4.Click += new System.EventHandler(this.bingoButton4_Click);
            // 
            // bingoButton3
            // 
            this.bingoButton3.Location = new System.Drawing.Point(206, 105);
            this.bingoButton3.Name = "bingoButton3";
            this.bingoButton3.Size = new System.Drawing.Size(80, 80);
            this.bingoButton3.TabIndex = 5;
            this.bingoButton3.TabStop = false;
            this.bingoButton3.Text = "3";
            this.bingoButton3.UseVisualStyleBackColor = true;
            this.bingoButton3.Click += new System.EventHandler(this.bingoButton3_Click);
            // 
            // bingoButton8
            // 
            this.bingoButton8.Location = new System.Drawing.Point(206, 191);
            this.bingoButton8.Name = "bingoButton8";
            this.bingoButton8.Size = new System.Drawing.Size(80, 80);
            this.bingoButton8.TabIndex = 10;
            this.bingoButton8.TabStop = false;
            this.bingoButton8.Text = "8";
            this.bingoButton8.UseVisualStyleBackColor = true;
            this.bingoButton8.Click += new System.EventHandler(this.bingoButton8_Click);
            // 
            // bingoButton9
            // 
            this.bingoButton9.Location = new System.Drawing.Point(301, 191);
            this.bingoButton9.Name = "bingoButton9";
            this.bingoButton9.Size = new System.Drawing.Size(80, 80);
            this.bingoButton9.TabIndex = 9;
            this.bingoButton9.TabStop = false;
            this.bingoButton9.Text = "9";
            this.bingoButton9.UseVisualStyleBackColor = true;
            this.bingoButton9.Click += new System.EventHandler(this.bingoButton9_Click);
            // 
            // bingoButton7
            // 
            this.bingoButton7.Location = new System.Drawing.Point(111, 191);
            this.bingoButton7.Name = "bingoButton7";
            this.bingoButton7.Size = new System.Drawing.Size(80, 80);
            this.bingoButton7.TabIndex = 8;
            this.bingoButton7.TabStop = false;
            this.bingoButton7.Text = "7";
            this.bingoButton7.UseVisualStyleBackColor = true;
            this.bingoButton7.Click += new System.EventHandler(this.bingoButton7_Click);
            // 
            // bingoButton10
            // 
            this.bingoButton10.Location = new System.Drawing.Point(396, 191);
            this.bingoButton10.Name = "bingoButton10";
            this.bingoButton10.Size = new System.Drawing.Size(80, 80);
            this.bingoButton10.TabIndex = 7;
            this.bingoButton10.TabStop = false;
            this.bingoButton10.Text = "10";
            this.bingoButton10.UseVisualStyleBackColor = true;
            this.bingoButton10.Click += new System.EventHandler(this.bingoButton10_Click);
            // 
            // bingoButton6
            // 
            this.bingoButton6.Location = new System.Drawing.Point(16, 191);
            this.bingoButton6.Name = "bingoButton6";
            this.bingoButton6.Size = new System.Drawing.Size(80, 80);
            this.bingoButton6.TabIndex = 6;
            this.bingoButton6.TabStop = false;
            this.bingoButton6.Text = "6";
            this.bingoButton6.UseVisualStyleBackColor = true;
            this.bingoButton6.Click += new System.EventHandler(this.bingoButton6_Click);
            // 
            // bingoButtonFree
            // 
            this.bingoButtonFree.Location = new System.Drawing.Point(206, 277);
            this.bingoButtonFree.Name = "bingoButtonFree";
            this.bingoButtonFree.Size = new System.Drawing.Size(80, 80);
            this.bingoButtonFree.TabIndex = 15;
            this.bingoButtonFree.TabStop = false;
            this.bingoButtonFree.Text = "Free";
            this.bingoButtonFree.UseVisualStyleBackColor = true;
            this.bingoButtonFree.Click += new System.EventHandler(this.bingoButtonFree_Click);
            // 
            // bingoButton14
            // 
            this.bingoButton14.Location = new System.Drawing.Point(301, 277);
            this.bingoButton14.Name = "bingoButton14";
            this.bingoButton14.Size = new System.Drawing.Size(80, 80);
            this.bingoButton14.TabIndex = 14;
            this.bingoButton14.TabStop = false;
            this.bingoButton14.Text = "14";
            this.bingoButton14.UseVisualStyleBackColor = true;
            this.bingoButton14.Click += new System.EventHandler(this.bingoButton14_Click);
            // 
            // bingoButton12
            // 
            this.bingoButton12.Location = new System.Drawing.Point(111, 277);
            this.bingoButton12.Name = "bingoButton12";
            this.bingoButton12.Size = new System.Drawing.Size(80, 80);
            this.bingoButton12.TabIndex = 13;
            this.bingoButton12.TabStop = false;
            this.bingoButton12.Text = "12";
            this.bingoButton12.UseVisualStyleBackColor = true;
            this.bingoButton12.Click += new System.EventHandler(this.bingoButton12_Click);
            // 
            // bingoButton15
            // 
            this.bingoButton15.Location = new System.Drawing.Point(396, 277);
            this.bingoButton15.Name = "bingoButton15";
            this.bingoButton15.Size = new System.Drawing.Size(80, 80);
            this.bingoButton15.TabIndex = 12;
            this.bingoButton15.TabStop = false;
            this.bingoButton15.Text = "15";
            this.bingoButton15.UseVisualStyleBackColor = true;
            this.bingoButton15.Click += new System.EventHandler(this.bingoButton15_Click);
            // 
            // bingoButton11
            // 
            this.bingoButton11.Location = new System.Drawing.Point(16, 277);
            this.bingoButton11.Name = "bingoButton11";
            this.bingoButton11.Size = new System.Drawing.Size(80, 80);
            this.bingoButton11.TabIndex = 11;
            this.bingoButton11.TabStop = false;
            this.bingoButton11.Text = "11";
            this.bingoButton11.UseVisualStyleBackColor = true;
            this.bingoButton11.Click += new System.EventHandler(this.bingoButton11_Click);
            // 
            // bingoButton18
            // 
            this.bingoButton18.Location = new System.Drawing.Point(206, 363);
            this.bingoButton18.Name = "bingoButton18";
            this.bingoButton18.Size = new System.Drawing.Size(80, 80);
            this.bingoButton18.TabIndex = 20;
            this.bingoButton18.TabStop = false;
            this.bingoButton18.Text = "18";
            this.bingoButton18.UseVisualStyleBackColor = true;
            this.bingoButton18.Click += new System.EventHandler(this.bingoButton18_Click);
            // 
            // bingoButton19
            // 
            this.bingoButton19.Location = new System.Drawing.Point(301, 363);
            this.bingoButton19.Name = "bingoButton19";
            this.bingoButton19.Size = new System.Drawing.Size(80, 80);
            this.bingoButton19.TabIndex = 19;
            this.bingoButton19.TabStop = false;
            this.bingoButton19.Text = "19";
            this.bingoButton19.UseVisualStyleBackColor = true;
            this.bingoButton19.Click += new System.EventHandler(this.bingoButton19_Click);
            // 
            // bingoButton17
            // 
            this.bingoButton17.Location = new System.Drawing.Point(111, 363);
            this.bingoButton17.Name = "bingoButton17";
            this.bingoButton17.Size = new System.Drawing.Size(80, 80);
            this.bingoButton17.TabIndex = 18;
            this.bingoButton17.TabStop = false;
            this.bingoButton17.Text = "17";
            this.bingoButton17.UseVisualStyleBackColor = true;
            this.bingoButton17.Click += new System.EventHandler(this.bingoButton17_Click);
            // 
            // bingoButton20
            // 
            this.bingoButton20.Location = new System.Drawing.Point(396, 363);
            this.bingoButton20.Name = "bingoButton20";
            this.bingoButton20.Size = new System.Drawing.Size(80, 80);
            this.bingoButton20.TabIndex = 17;
            this.bingoButton20.TabStop = false;
            this.bingoButton20.Text = "20";
            this.bingoButton20.UseVisualStyleBackColor = true;
            this.bingoButton20.Click += new System.EventHandler(this.bingoButton20_Click);
            // 
            // bingoButton16
            // 
            this.bingoButton16.Location = new System.Drawing.Point(16, 363);
            this.bingoButton16.Name = "bingoButton16";
            this.bingoButton16.Size = new System.Drawing.Size(80, 80);
            this.bingoButton16.TabIndex = 16;
            this.bingoButton16.TabStop = false;
            this.bingoButton16.Text = "16";
            this.bingoButton16.UseVisualStyleBackColor = true;
            this.bingoButton16.Click += new System.EventHandler(this.bingoButton16_Click);
            // 
            // bingoButton23
            // 
            this.bingoButton23.Location = new System.Drawing.Point(206, 449);
            this.bingoButton23.Name = "bingoButton23";
            this.bingoButton23.Size = new System.Drawing.Size(80, 80);
            this.bingoButton23.TabIndex = 25;
            this.bingoButton23.TabStop = false;
            this.bingoButton23.Text = "23";
            this.bingoButton23.UseVisualStyleBackColor = true;
            this.bingoButton23.Click += new System.EventHandler(this.bingoButton23_Click);
            // 
            // bingoButton24
            // 
            this.bingoButton24.Location = new System.Drawing.Point(301, 449);
            this.bingoButton24.Name = "bingoButton24";
            this.bingoButton24.Size = new System.Drawing.Size(80, 80);
            this.bingoButton24.TabIndex = 24;
            this.bingoButton24.TabStop = false;
            this.bingoButton24.Text = "24";
            this.bingoButton24.UseVisualStyleBackColor = true;
            this.bingoButton24.Click += new System.EventHandler(this.bingoButton24_Click);
            // 
            // bingoButton22
            // 
            this.bingoButton22.Location = new System.Drawing.Point(111, 449);
            this.bingoButton22.Name = "bingoButton22";
            this.bingoButton22.Size = new System.Drawing.Size(80, 80);
            this.bingoButton22.TabIndex = 23;
            this.bingoButton22.TabStop = false;
            this.bingoButton22.Text = "22";
            this.bingoButton22.UseVisualStyleBackColor = true;
            this.bingoButton22.Click += new System.EventHandler(this.bingoButton22_Click);
            // 
            // bingoButton25
            // 
            this.bingoButton25.Location = new System.Drawing.Point(396, 449);
            this.bingoButton25.Name = "bingoButton25";
            this.bingoButton25.Size = new System.Drawing.Size(80, 80);
            this.bingoButton25.TabIndex = 22;
            this.bingoButton25.TabStop = false;
            this.bingoButton25.Text = "25";
            this.bingoButton25.UseVisualStyleBackColor = true;
            this.bingoButton25.Click += new System.EventHandler(this.bingoButton25_Click);
            // 
            // bingoButton21
            // 
            this.bingoButton21.Location = new System.Drawing.Point(16, 449);
            this.bingoButton21.Name = "bingoButton21";
            this.bingoButton21.Size = new System.Drawing.Size(80, 80);
            this.bingoButton21.TabIndex = 21;
            this.bingoButton21.TabStop = false;
            this.bingoButton21.Text = "21";
            this.bingoButton21.UseVisualStyleBackColor = true;
            this.bingoButton21.Click += new System.EventHandler(this.bingoButton21_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(443, 73);
            this.label1.TabIndex = 26;
            this.label1.Text = "Meeting Bingo";
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(200, 555);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(90, 29);
            this.resetButton.TabIndex = 28;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(350, 555);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(90, 29);
            this.exitButton.TabIndex = 29;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // shuffleButton
            // 
            this.shuffleButton.Location = new System.Drawing.Point(53, 555);
            this.shuffleButton.Name = "shuffleButton";
            this.shuffleButton.Size = new System.Drawing.Size(90, 29);
            this.shuffleButton.TabIndex = 27;
            this.shuffleButton.Text = "Shuffle";
            this.shuffleButton.UseVisualStyleBackColor = true;
            this.shuffleButton.Click += new System.EventHandler(this.shuffleButton_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Location = new System.Drawing.Point(17, 5);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(500, 650);
            this.tabControl.TabIndex = 30;
            this.tabControl.TabStop = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.bingoWinBox);
            this.tabPage1.Controls.Add(this.bingoButton2);
            this.tabPage1.Controls.Add(this.shuffleButton);
            this.tabPage1.Controls.Add(this.bingoButton1);
            this.tabPage1.Controls.Add(this.exitButton);
            this.tabPage1.Controls.Add(this.bingoButton5);
            this.tabPage1.Controls.Add(this.resetButton);
            this.tabPage1.Controls.Add(this.bingoButton4);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.bingoButton3);
            this.tabPage1.Controls.Add(this.bingoButton23);
            this.tabPage1.Controls.Add(this.bingoButton6);
            this.tabPage1.Controls.Add(this.bingoButton24);
            this.tabPage1.Controls.Add(this.bingoButton10);
            this.tabPage1.Controls.Add(this.bingoButton22);
            this.tabPage1.Controls.Add(this.bingoButton7);
            this.tabPage1.Controls.Add(this.bingoButton25);
            this.tabPage1.Controls.Add(this.bingoButton9);
            this.tabPage1.Controls.Add(this.bingoButton21);
            this.tabPage1.Controls.Add(this.bingoButton8);
            this.tabPage1.Controls.Add(this.bingoButton18);
            this.tabPage1.Controls.Add(this.bingoButton11);
            this.tabPage1.Controls.Add(this.bingoButton19);
            this.tabPage1.Controls.Add(this.bingoButton15);
            this.tabPage1.Controls.Add(this.bingoButton17);
            this.tabPage1.Controls.Add(this.bingoButton12);
            this.tabPage1.Controls.Add(this.bingoButton20);
            this.tabPage1.Controls.Add(this.bingoButton14);
            this.tabPage1.Controls.Add(this.bingoButton16);
            this.tabPage1.Controls.Add(this.bingoButtonFree);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(492, 624);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Bingo";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(492, 624);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Rules";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 564);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(196, 16);
            this.label10.TabIndex = 8;
            this.label10.Text = "8. You may only Shuffle 2 times. ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 514);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(328, 16);
            this.label9.TabIndex = 7;
            this.label9.Text = "7. “*Chirp*” is a smoke detector, change battery sound.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(10, 464);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(246, 16);
            this.label8.TabIndex = 6;
            this.label8.Text = "6. “Spiritual Pet” is when a pet is in frame.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 398);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(457, 32);
            this.label7.TabIndex = 5;
            this.label7.Text = "5. “Spotty Video” does not count if it is only Green Screen issues. If the green " +
    "\r\nscreen is ONLY VISIBLE, that means their video is “Spotty”.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(10, 332);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(444, 32);
            this.label6.TabIndex = 4;
            this.label6.Text = "4. “American Gothic painting” is when both Chad and Tavia Hicks are both \r\nin fra" +
    "me.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(463, 32);
            this.label5.TabIndex = 3;
            this.label5.Text = "3. “Request from AV brother denied” is when the speaker asks the AV brother \r\nto " +
    "do something but that is not possible.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(363, 32);
            this.label4.TabIndex = 2;
            this.label4.Text = "2. A “Photobomb” is only allowed with a person, not a pet. \r\n(Photobomb can also " +
    "count with “American Gothic Painting”.)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(477, 64);
            this.label3.TabIndex = 1;
            this.label3.Text = resources.GetString("label3.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(92, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(309, 37);
            this.label2.TabIndex = 0;
            this.label2.Text = "Meeting Bingo Rules";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(492, 624);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Patch Notes";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(20, 59);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label12.Size = new System.Drawing.Size(443, 324);
            this.label12.TabIndex = 2;
            this.label12.Text = resources.GetString("label12.Text");
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(137, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(192, 37);
            this.label11.TabIndex = 1;
            this.label11.Text = "Patch Notes";
            // 
            // bingoWinBox
            // 
            this.bingoWinBox.Location = new System.Drawing.Point(189, 594);
            this.bingoWinBox.Name = "bingoWinBox";
            this.bingoWinBox.Size = new System.Drawing.Size(110, 20);
            this.bingoWinBox.TabIndex = 30;
            this.bingoWinBox.Text = "Bingo Wins: 0";
            this.bingoWinBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // startupForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(534, 661);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "startupForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Meeting Bingo";
            this.Load += new System.EventHandler(this.startupForm_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bingoButton1;
        private System.Windows.Forms.Button bingoButton5;
        private System.Windows.Forms.Button bingoButton2;
        private System.Windows.Forms.Button bingoButton4;
        private System.Windows.Forms.Button bingoButton3;
        private System.Windows.Forms.Button bingoButton8;
        private System.Windows.Forms.Button bingoButton9;
        private System.Windows.Forms.Button bingoButton7;
        private System.Windows.Forms.Button bingoButton10;
        private System.Windows.Forms.Button bingoButton6;
        private System.Windows.Forms.Button bingoButtonFree;
        private System.Windows.Forms.Button bingoButton14;
        private System.Windows.Forms.Button bingoButton12;
        private System.Windows.Forms.Button bingoButton15;
        private System.Windows.Forms.Button bingoButton11;
        private System.Windows.Forms.Button bingoButton18;
        private System.Windows.Forms.Button bingoButton19;
        private System.Windows.Forms.Button bingoButton17;
        private System.Windows.Forms.Button bingoButton20;
        private System.Windows.Forms.Button bingoButton16;
        private System.Windows.Forms.Button bingoButton23;
        private System.Windows.Forms.Button bingoButton24;
        private System.Windows.Forms.Button bingoButton22;
        private System.Windows.Forms.Button bingoButton25;
        private System.Windows.Forms.Button bingoButton21;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button shuffleButton;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox bingoWinBox;
    }
}

